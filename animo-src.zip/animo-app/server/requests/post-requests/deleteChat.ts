import mongodb from 'mongodb';

import {
	COLLECTIONS,
	STATUS_CODE,
	MONGO_CONSTANTS
} from './../../constants';

export const deleteChat = (mongoClient: typeof mongodb.MongoClient, postReq: any, postRes: any) => {
	console.log("Deleting chat...");

	const obj = postReq.body;
	mongoClient.connect(MONGO_CONSTANTS.MONGO_URL, { useNewUrlParser: true }, (connerErr, db) => {
		if (connerErr) throw connerErr;
		const dbo = db.db(MONGO_CONSTANTS.DATABASE_NAME);
		dbo.collection(COLLECTIONS.CHATS_COLLECTION).deleteOne({"chatTitle":obj.id}, (insertChatErr, insertChatRes) => {
			if (insertChatErr) throw insertChatErr;
            db.close();
            postRes.json({
                statusMessage: STATUS_CODE.SUCCESS
            });

		});
	});
};
