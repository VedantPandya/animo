

import * as React from 'react';

import * as classes from './crisis.css';

interface ICrsisProps {
}

const Crsis = (props: ICrsisProps) => {
    const {
    } = props;

    return (
        <div className={classes.CrisisContainer}>
            <div className={classes.CrisisWrapper}>
                <div className={classes.LeftPane}>
                    <div className={classes.Label1}>I would like to speak with a therapist on the phone</div>
                    <div className={classes.Label2}>Our professional therapists are available 24/7</div>
                    <div className={classes.Label3}>(022) 28057926</div>
                </div>
                <div className={classes.RightPane}>
                    <div className={classes.Label1}>I would like to message a therapist online</div>
                    <div className={classes.Label2}>Online messaging services open Monday to Friday 8 am to 5 pm</div>
                    
                </div>
            </div>
            <div className={classes.Warning}>If you are experiencing a medical emergency, please call 1-0-0</div>
        </div>
    );
};

export default Crsis;