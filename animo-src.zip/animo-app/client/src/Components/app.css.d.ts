export const AppContainer: string;
export const AppFooter: string;
