export const Icon: string;
export const Text: string;
export const IconInfo: string;
export const TableCell: string;
