export const NavigationBar: string;
export const NavigationBarLeft: string;
export const NavigationBarTitleLink: string;
export const NavigationBarRight: string;
export const NavigationBarLoginLink: string;
export const Link: string;
