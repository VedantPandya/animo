export const DashboardTileContainer: string;
export const DashboardTileHeader: string;
export const DashboardTileButtonFlexbox: string;
