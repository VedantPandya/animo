export const TrendingPostsPreviewLabel: string;
export const TrendingPostsPreviewMessageLink: string;
export const TrendingPostsPreviewMessage: string;
export const TrendingPostsPreviewImage: string;
