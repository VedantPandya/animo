export const DashboardTileButtonLink: string;
export const DashboardTileButtonWrapper: string;
export const DashboardTileButton: string;
export const DashboardTileButton_BlueBackground: string;
export const DashboardTileButton_WhiteBackground: string;
export const TextAlignCenter: string;
export const TextAlignEnd: string;
