export const SearchBar: string;
export const TextInput: string;
export const SubmitInput: string;
export const SearchIcon: string;
