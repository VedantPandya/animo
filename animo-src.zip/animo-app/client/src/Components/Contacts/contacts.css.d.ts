export const Container: string;
export const Header: string;
export const ContactContainer: string;
export const Title: string;
export const Description: string;
export const Link: string;
