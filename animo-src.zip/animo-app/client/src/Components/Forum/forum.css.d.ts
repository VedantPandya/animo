export const ForumContainer: string;
export const ForumTitle: string;
export const CreateChatButton: string;
