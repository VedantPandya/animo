export const LoadingContainer: string;
