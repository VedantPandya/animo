export const InfoCardLinkContainer: string;
export const InfoCardContainer: string;
export const Title: string;
export const Name: string;
export const ProfilePicture: string;
export const IconDetailsContainer: string;
