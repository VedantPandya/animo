export const TopicTile: string;
export const Title: string;
export const Image: string;
