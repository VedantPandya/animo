export const TrendingKeywordsPreviewWords: string;
export const TrendingKeywordsWordsContainer: string;
export const TrendingKeywordsWords: string;
