export const Container: string;
export const SearchBarContainer: string;
export const ForumTable: string;
export const ForumTableCell: string;
export const TopicLink: string;
export const TileContainer: string;
export const Loading: string;
