export const CreateForm: string;
export const CreateFormTitle: string;
export const SubmitButton: string;
export const TextInput: string;
