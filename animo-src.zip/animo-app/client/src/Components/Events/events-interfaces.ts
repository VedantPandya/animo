export interface IEventsData {
    _id: string;
    title: string;
    date?: string;
    location?: string;
    desc: string;
}