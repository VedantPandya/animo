export const Header: string;
export const Loading: string;
