// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.

export const chats = {
    "8xf0y6ziyjabvozdd253nd": {
        id: '8xf0y6ziyjabvozdd253nd',
        title: 'Help dealing with anxiety',
        author: 'eddylu',
        timestamp: 1467166872630,
        messages: [
            {
                id: '1',
                author: 'sarahedo',
                message: 'I have a good solution',
                timestamp: 1467166872634
            },
            {
                id: '2',
                author: 'joebranger',
                message: 'Good idea!',
                timestamp: 1467166872639
            },
            {
                id: '3',
                author: 'eddylu',
                message: 'Thanks!',
                timestamp: 1467166872645
            },
            {
                id: '4',
                author: 'sarahedo',
                message: 'I have a good solution',
                timestamp: 1467166872634
            },
            {
                id: '5',
                author: 'joebranger',
                message: 'Good idea!',
                timestamp: 1467166872639
            },
            {
                id: '6',
                author: 'eddylu',
                message: 'Thanks!',
                timestamp: 1467166872645
            },
            {
                id: '7',
                author: 'sarahedo',
                message: 'I have a good solution',
                timestamp: 1467166872634
            },
            {
                id: '8',
                author: 'joebranger',
                message: 'Good idea!',
                timestamp: 1467166872639
            },
            {
                id: '9',
                author: 'eddylu',
                message: 'Thanks!',
                timestamp: 1467166872645
            }
        ]
    },
    "6ni6ok3ym7mf1p33lnez": {
        id: '6ni6ok3ym7mf1p33lnez',
        author: 'johndoe',
        timestamp: 1468479767190,
    },
    "am8ehyc8byjqgar0jgpub9": {
        id: 'am8ehyc8byjqgar0jgpub9',
        author: 'sarahedo',
        timestamp: 1488579767190,
    },
    "loxhs1bqm25b708cmbf3g": {
        id: 'loxhs1bqm25b708cmbf3g',
        author: 'tylermcginnis',
        timestamp: 1482579767190,
    },
    "vthrdm985a262al8qx3do": {
        id: 'vthrdm985a262al8qx3do',
        author: 'tylermcginnis',
        timestamp: 1489579767190,
    },
}